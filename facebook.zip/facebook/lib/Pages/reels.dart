import 'package:flutter/material.dart';

class Reelspages extends StatefulWidget {
  const Reelspages({super.key});

  @override
  State<Reelspages> createState() => _ReelspagesState();
}

class _ReelspagesState extends State<Reelspages> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}