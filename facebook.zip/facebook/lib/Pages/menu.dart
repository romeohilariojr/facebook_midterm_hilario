import 'package:flutter/material.dart';

class Menupages extends StatefulWidget {
  const Menupages({super.key});

  @override
  State<Menupages> createState() => _MenupagesState();
}

class _MenupagesState extends State<Menupages> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}