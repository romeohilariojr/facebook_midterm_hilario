import 'package:flutter/material.dart';

class FriendsPages extends StatefulWidget {
  const FriendsPages({super.key});

  @override
  State<FriendsPages> createState() => _FriendsPagesState();
}

class _FriendsPagesState extends State<FriendsPages> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}